﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q10
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                Console.WriteLine("Enter Your Choice:");
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Subtract");
                Console.WriteLine("3.Multiplication");
                Console.WriteLine("4.Division");
                Console.WriteLine("5.Exit");
                try
                {
                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {

                        case 1:
                            Console.WriteLine("Enter First Number");
                            int num1 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Second Number");
                            int num2 = int.Parse(Console.ReadLine());
                            int sum = num1 + num2;
                            Console.WriteLine("Addition=" + sum);
                            break;

                        case 2:
                            Console.WriteLine("Enter First Number");
                            int num3 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Second Number");
                            int num4 = int.Parse(Console.ReadLine());
                            int sub = num3 + num4;
                            Console.WriteLine("Substraction=" + sub);
                            break;

                        case 3:
                            Console.WriteLine("Enter First Number");
                            int num5 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Second Number");
                            int num6 = int.Parse(Console.ReadLine());
                            int mul = num5 + num6;
                            Console.WriteLine("Multiplication=" + mul);
                            break;

                        case 4:
                            Console.WriteLine("Enter First Number");
                            int num7 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Second Number");
                            int num8 = int.Parse(Console.ReadLine());
                            int div = num7 + num8;
                            Console.WriteLine("Division=" + div);
                            break;

                        case 5:
                            return;

                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            } 
        }
    }
}
