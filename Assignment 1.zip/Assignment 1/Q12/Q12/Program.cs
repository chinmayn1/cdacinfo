﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******Employee Management System*****");
            try
            {

                int[] empno = new int[5];
                String[] depname = new String[5];
                char[] position = new char[5];
                String[] designation = new String[5];

                for (int i = 0; i < 2; i++)
                {
                    Console.WriteLine("Enter Department Number");
                    empno[i] = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Department Name");
                    depname[i] = Console.ReadLine();
                    Console.WriteLine("Enter Initial Character of Position");
                    position[i] = char.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Employee Designation");
                    designation[i] = Console.ReadLine();
                }
                Console.WriteLine("Enter Department No to Find");
                int find = int.Parse(Console.ReadLine());
                int flag = 0;
                for (int i = 0; i < 5; i++)
                {
                    
                    if (find == empno[i])
                    {
                        flag = 1;
                        Console.WriteLine("Department Number=" + empno[i]);
                        Console.WriteLine("Department Name="+depname[i]);
                        Console.WriteLine("Designamtion Code="+position[i]);
                        Console.WriteLine("Designation=" + designation[i]);
                    }
                }
                if (flag==0)
                {
                    Console.WriteLine("Employee Not Found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
