﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q9
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                float commision = 0;
                Console.WriteLine("Enter Basic Salary");
                float bsalary = float.Parse(Console.ReadLine());

                Console.WriteLine("Enter Total Sales");
                float sales = float.Parse(Console.ReadLine());

                Console.WriteLine("Basic Salary=" + bsalary);

                if (sales >= 5000 && sales <= 7500)
                {
                    commision = (3 * sales) / 100;
                }

                else if (sales >= 7501 && sales <= 10500)
                {
                    commision = (8 * sales) / 100;
                }

                else if (sales >= 10501 && sales <= 15000)
                {
                    commision = (11 * sales) / 100;
                }

                else
                {
                    commision = (15 * sales) / 100;
                }
                Console.WriteLine("Commision=" + commision);
                float totalsalary = bsalary + commision;
                Console.WriteLine("Net Salary="+totalsalary);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
