﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q13
{
    class Program
    {
        static void Main(string[] args)
        {
                        Console.WriteLine("*****Calender*****");
            try
            {
                Console.WriteLine("Enter Date");
                int date = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Month");
                int month = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Year");
                int year = int.Parse(Console.ReadLine());

                if (month == 01 || month == 03 || month == 05 || month == 07 || month == 08 || month == 10 || month == 12)
                {
                    Console.WriteLine("Total Number of Days in " + month + " are 31");
                }
                else if (month == 04 || month == 06 || month == 09 || month == 11)
                {
                    Console.WriteLine("Total Number of Days in " + month + " are 30");
                }
                else
                {
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
                    {
                        Console.WriteLine("Total Number of Days in " + month + " are 29");
                    }
                    else
                    {
                        Console.WriteLine("Total Number of Days in " + month + " are 28");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
                        Console.ReadLine();
        }
    }
}
