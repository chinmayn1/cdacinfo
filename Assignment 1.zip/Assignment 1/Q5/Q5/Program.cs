﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter First Number");
                int num1 = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Second Number");
                int num2 = int.Parse(Console.ReadLine());

                int temp = num1;
                num1 = num2;
                num2 = temp;

                Console.WriteLine("After Swap   " + num1 + " " + num2);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
