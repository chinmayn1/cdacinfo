﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q8
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             *          Using If-Else and Logical
             *          
             *            try
                        {
                            Console.WriteLine("Enter a Year");
                            int year = int.Parse(Console.ReadLine());

                            if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
                            {
                                Console.WriteLine(year + " is a Leap Year", year);
                            }
                            else
                            {
                                Console.WriteLine(year + " is not a Leap Year", year);
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        Console.ReadLine();
            */

            try
            {
                Console.WriteLine("Enter a Year");
                int year = int.Parse(Console.ReadLine());

                Console.WriteLine((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) ? "Entered year is a leap" : "Not leap year");

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
