﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Q15
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                for (byte counter = 0,i=0; counter < 255; counter++,i++)
                {
                    Console.Write(" "+(char)counter);
                    if (i == 10)
                    { 
                        Thread.Sleep(500);
                        i = 0;
                        Console.WriteLine();
                    }
                }
            }
           
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
