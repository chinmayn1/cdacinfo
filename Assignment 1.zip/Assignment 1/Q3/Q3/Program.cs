﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                float sum = 0;
                Console.WriteLine("Enter Marks of 5 Students");

                int[] marks = new int[5];
                for (int i = 0; i < 5; i++)
                {
                    marks[i] = int.Parse(Console.ReadLine());
                    sum = sum + marks[i];
                }
                Console.WriteLine("Average Marks=" + sum);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();

        }
    }
}
