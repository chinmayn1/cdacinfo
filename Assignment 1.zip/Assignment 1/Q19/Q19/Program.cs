﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q19
{
    class Program
    {
        static void Main(string[] args)
        {
            int first = 1,sum=0;
            Console.WriteLine("Enter a Number");
            int num = int.Parse(Console.ReadLine());
            Console.Write(first+" ");

            for (int i = 0; i < num; i++)
            {
                sum = sum + first;
                Console.WriteLine(sum);
            }
            Console.ReadKey();
        }
    }
}
