﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q18
{
    class Program
    {
        public static bool Check(int num)
        {

            if (num < 0)
                return false;
            else
                return true;
        }
        public static void Prime(int num)
        {
            int flag = 0, rem = 0;
            rem = num / 2;
            for (int i = 2; i < rem; i++)
            {
                if (num % i == 0)
                {
                    Console.WriteLine("Not Prime");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Prime");
            }
            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            try
            {

                Console.WriteLine("Enter a Number");
                int num = int.Parse(Console.ReadLine());

                bool chk = Check(num);
                if (chk == true)
                    Prime(num);
                else
                    Console.WriteLine("Please Enter Positive Number");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
