﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                char character;
                Console.WriteLine("Enter the character: ");
                character = Char.Parse(Console.ReadLine());
                Console.WriteLine("The ASCII value of " + character + " is " + (int)character);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
