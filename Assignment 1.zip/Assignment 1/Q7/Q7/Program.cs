﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q7
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the Basic Salary of Employee");
                float bsalary = float.Parse(Console.ReadLine());


                float hra = (20 * bsalary) / 100;
                float da = (40 * bsalary) / 100;
                float pf = (10 * bsalary) / 100;

                float gsalary = bsalary + hra + da;
                Console.WriteLine("Gross Salary=" + gsalary);

                float nsalary = gsalary - pf;
                Console.WriteLine("Net Salary=" + nsalary);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
