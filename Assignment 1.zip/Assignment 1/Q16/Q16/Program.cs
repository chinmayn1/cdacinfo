﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q16
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int flag = 0,rem=0;
                Console.WriteLine("Enter a Number");
                int num = int.Parse(Console.ReadLine());
                rem = num / 2;
                for (int i = 2; i < rem ; i++)
                {
                    if (num % i == 0)
                    {
                        Console.WriteLine("Not Prime");
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("Prime");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
